export {default as authController} from './Authentication/authController.js';
export {default as homeController} from './homeController.js';
export {default as productDetailsController} from './Customer/productDetailsController.js';
export {default as cartController} from './Customer/cartController.js';
export {default as productController} from './Customer/productController.js';
export {default as orderController} from './orderController.js';